/* Local compatibility header for libaio's public ABI while rebuilding fio.
 * Linux AIO wire formats are provided by linux/aio_abi.h; only used at build time.
 * The portable ZIP redistributes libaio under its own upstream license.
 */
#ifndef VITALUX_LIBAIO_ABI_H
#define VITALUX_LIBAIO_ABI_H
#include <linux/aio_abi.h>
#include <sys/uio.h>
#include <string.h>
#include <stdint.h>
#include <time.h>
typedef aio_context_t io_context_t;
extern int io_setup(int maxevents, io_context_t *ctxp);
#define io_queue_init io_setup
extern int io_destroy(io_context_t ctx);
extern int io_submit(io_context_t ctx, long nr, struct iocb **iocbpp);
extern int io_getevents(io_context_t ctx, long min_nr, long nr, struct io_event *events, struct timespec *timeout);
extern int io_cancel(io_context_t ctx, struct iocb *iocb, struct io_event *result);
static inline void vitalux_prep_iocb(struct iocb *iocb, int fd, unsigned short op,
                                    void *buf, unsigned long nr, long long offset)
{
    memset(iocb, 0, sizeof(*iocb));
    iocb->aio_lio_opcode = op;
    iocb->aio_fildes = fd;
    iocb->aio_buf = (uint64_t)(uintptr_t)buf;
    iocb->aio_nbytes = nr;
    iocb->aio_offset = offset;
}
static inline void io_prep_pread(struct iocb *iocb, int fd, void *buf, unsigned long nr, long long off)
{ vitalux_prep_iocb(iocb, fd, IOCB_CMD_PREAD, buf, nr, off); }
static inline void io_prep_pwrite(struct iocb *iocb, int fd, void *buf, unsigned long nr, long long off)
{ vitalux_prep_iocb(iocb, fd, IOCB_CMD_PWRITE, buf, nr, off); }
static inline void io_prep_preadv(struct iocb *iocb, int fd, const struct iovec *iov, int nr, long long off)
{ vitalux_prep_iocb(iocb, fd, IOCB_CMD_PREADV, (void *)iov, nr, off); }
static inline void io_prep_pwritev(struct iocb *iocb, int fd, const struct iovec *iov, int nr, long long off)
{ vitalux_prep_iocb(iocb, fd, IOCB_CMD_PWRITEV, (void *)iov, nr, off); }
static inline void io_prep_fsync(struct iocb *iocb, int fd)
{ vitalux_prep_iocb(iocb, fd, IOCB_CMD_FSYNC, (void *)0, 0, 0); }
#endif
